# Cryptoverse - Explore the World of Cryptocurrency

![Cryptoverse](https://i.ibb.co/8gh5Jc8/image.png)

### [🌟 Become a top 1% Next.js 13 developer in only one course](https://jsmastery.pro/next13)
### [🚀 Land your dream programming job in 6 months](https://jsmastery.pro/masterclass)

## Introduction
This is a code repository for the corresponding video tutorial. 

In this video, we will create a cryptocurrency app. We're going to use React and multiple APIs powered by https://rapidapi.com.

By the end of this video, you will become the master of working with APIs.
